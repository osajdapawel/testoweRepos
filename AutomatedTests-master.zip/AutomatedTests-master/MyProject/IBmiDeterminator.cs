﻿namespace MyProject
{
    public interface IBmiDeterminator
    {
        BmiClassification DetermineBmi(double bmi);
    }
}