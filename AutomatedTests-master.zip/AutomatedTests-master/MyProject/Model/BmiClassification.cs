﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyProject
{
    public enum BmiClassification
    {
        Underweight,
        Normal,
        Overweight,
        Obesity,
        ExtremeObesity
    }
}
