﻿namespace MyProject
{
    public class BmiResult
    {
        public double Bmi { get; set; }
        public BmiClassification BmiClassification { get; set; }
        public string Summary { get; set; }
    }
}
