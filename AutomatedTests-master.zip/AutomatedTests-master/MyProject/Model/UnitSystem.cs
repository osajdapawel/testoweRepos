﻿namespace MyProject
{
    public enum UnitSystem
    {
        Metric,
        Imperial
    }
}
